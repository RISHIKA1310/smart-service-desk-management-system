# 🖥️ Smart Service Desk Management System

A full-featured, web-based IT Service Desk built with **Python**, **Flask**, **MySQL**, **Bootstrap 5**, and a **REST API** — ready to deploy.

![Python](https://img.shields.io/badge/Python-3.10+-blue?logo=python&logoColor=white)
![Flask](https://img.shields.io/badge/Flask-3.0-black?logo=flask)
![MySQL](https://img.shields.io/badge/MySQL-8.0+-orange?logo=mysql&logoColor=white)
![Bootstrap](https://img.shields.io/badge/Bootstrap-5.3-purple?logo=bootstrap&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green)

---

## ✨ Features

- **Ticket Lifecycle Management** — Create, assign, update, and close tickets with full audit trail
- **SLA Tracking** — Auto due-dates by priority; real-time SLA compliance indicators (On Track / At Risk / Breached)
- **REST API** — Full CRUD JSON API for external integrations
- **Dashboard** — KPI cards, Chart.js charts, agent workload, and live activity feed
- **Role-Based Access** — Admin, Agent, and User roles
- **Filtering & Search** — Filter by status, priority, type; full-text search
- **Comments & Activity Log** — Internal notes, public replies, full history per ticket
- **Responsive Dark UI** — Bootstrap 5 dark theme, Chart.js, mobile-friendly

---

## 📁 Project Structure

```
service_desk/
├── app.py                  # Flask application factory
├── config.py               # Config classes (dev/prod) + dotenv
├── extensions.py           # SQLAlchemy instance
├── models.py               # DB models + seed data
├── requirements.txt
├── schema.sql              # MySQL DDL with indexes
├── .env.example            # Environment variable template
│
├── routes/
│   ├── __init__.py
│   ├── dashboard.py        # Dashboard view
│   ├── tickets.py          # Ticket CRUD (list, new, view, update, comment)
│   ├── api.py              # REST API endpoints
│   └── auth.py             # Login / logout
│
├── templates/
│   ├── base.html           # Sidebar layout shell
│   ├── dashboard.html      # Main dashboard with charts
│   ├── auth/
│   │   └── login.html
│   └── tickets/
│       ├── list.html       # Ticket list with filters
│       ├── new.html        # Create ticket form
│       └── view.html       # Ticket detail + comments + activity
│
└── static/
    ├── css/style.css       # Dark theme styles
    └── js/main.js          # Search + badge refresh
```

---

## 🚀 Quick Start

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/smart-service-desk.git
cd smart-service-desk
```

### 2. Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure environment variables
```bash
cp .env.example .env
# Edit .env with your MySQL credentials and secret key
```

### 5. Set up the MySQL database
```bash
mysql -u root -p < schema.sql
```
> The app also auto-creates tables and seeds demo data on first run via SQLAlchemy.

### 6. Run the application
```bash
python app.py
```

Visit: **http://localhost:5000**

---

## 🔐 Demo Accounts

| Email | Role |
|---|---|
| alex@company.com | Admin |
| jordan@company.com | Agent |
| sam@company.com | Agent |
| chris@company.com | User |
| dana@company.com | User |

> No password required in demo mode — just enter the email.

---

## 🌐 REST API Reference

Base URL: `http://localhost:5000/api`

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/tickets` | List tickets (`?status=open&priority=high`) |
| `POST` | `/tickets` | Create a new ticket |
| `GET` | `/tickets/:id` | Get ticket by ID |
| `PUT` | `/tickets/:id` | Update ticket fields |
| `DELETE` | `/tickets/:id` | Delete a ticket |
| `GET` | `/stats` | Dashboard statistics |
| `GET` | `/users` | List all users |
| `GET` | `/categories` | List categories |
| `GET` | `/sla-policies` | List SLA policies |

### Example: Create a Ticket
```bash
curl -X POST http://localhost:5000/api/tickets \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Email not syncing",
    "description": "Outlook not syncing since 9am.",
    "priority": "high",
    "type": "incident",
    "requester_id": 4
  }'
```

### Example: Get Stats
```bash
curl http://localhost:5000/api/stats
```

---

## 📊 SLA Policy Matrix

| Priority | Response Time | Resolution Time |
|---|---|---|
| 🔴 Critical | 1 hour | 4 hours |
| 🟠 High | 4 hours | 8 hours |
| 🔵 Medium | 8 hours | 24 hours |
| ⚪ Low | 24 hours | 72 hours |

---

## 🗄️ Database Schema

**Core Tables:**

| Table | Description |
|---|---|
| `users` | Admins, agents, and end users |
| `tickets` | Core ticket records with lifecycle fields |
| `categories` | Ticket classification (Hardware, Software, etc.) |
| `sla_policies` | SLA rules per priority level |
| `comments` | Public replies and internal notes |
| `activities` | Full audit log of ticket changes |

See [`schema.sql`](schema.sql) for the full DDL with indexes.

---

## 🛠️ Tech Stack

| Component | Technology |
|---|---|
| Backend | Python 3.10+, Flask 3.0, Flask-SQLAlchemy |
| Database | MySQL 8.0+ (PyMySQL driver) |
| Frontend | HTML5, Bootstrap 5.3, Chart.js 4 |
| Styling | Custom CSS (dark theme, CSS variables) |
| API | RESTful JSON (Flask Blueprints) |
| Config | python-dotenv |

---

## 📄 License

MIT License — free to use, modify, and distribute.
