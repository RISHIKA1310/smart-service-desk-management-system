from flask import Flask
from config import Config
from extensions import db
from routes.tickets import tickets_bp
from routes.dashboard import dashboard_bp
from routes.api import api_bp
from routes.auth import auth_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)

    app.register_blueprint(dashboard_bp)
    app.register_blueprint(tickets_bp, url_prefix='/tickets')
    app.register_blueprint(api_bp, url_prefix='/api')
    app.register_blueprint(auth_bp, url_prefix='/auth')

    with app.app_context():
        db.create_all()
        from models import seed_data
        seed_data()

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
