from extensions import db
from datetime import datetime, timedelta


class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    role = db.Column(db.String(50), default='user')  # admin, agent, user
    department = db.Column(db.String(100))
    avatar_initials = db.Column(db.String(5))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    tickets_created = db.relationship('Ticket', foreign_keys='Ticket.requester_id', backref='requester', lazy=True)
    tickets_assigned = db.relationship('Ticket', foreign_keys='Ticket.assignee_id', backref='assignee', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'role': self.role,
            'department': self.department,
        }


class Category(db.Model):
    __tablename__ = 'categories'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(255))
    tickets = db.relationship('Ticket', backref='category', lazy=True)

    def to_dict(self):
        return {'id': self.id, 'name': self.name}


class SLAPolicy(db.Model):
    __tablename__ = 'sla_policies'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    priority = db.Column(db.String(20), nullable=False)  # critical, high, medium, low
    response_time_hours = db.Column(db.Integer, nullable=False)
    resolution_time_hours = db.Column(db.Integer, nullable=False)
    tickets = db.relationship('Ticket', backref='sla_policy', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'priority': self.priority,
            'response_time_hours': self.response_time_hours,
            'resolution_time_hours': self.resolution_time_hours,
        }


class Ticket(db.Model):
    __tablename__ = 'tickets'
    id = db.Column(db.Integer, primary_key=True)
    ticket_number = db.Column(db.String(20), unique=True, nullable=False)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(50), default='open')  # open, in_progress, pending, resolved, closed
    priority = db.Column(db.String(20), default='medium')  # critical, high, medium, low
    type = db.Column(db.String(50), default='incident')  # incident, service_request, change, problem
    requester_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    assignee_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=True)
    sla_policy_id = db.Column(db.Integer, db.ForeignKey('sla_policies.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    resolved_at = db.Column(db.DateTime, nullable=True)
    due_date = db.Column(db.DateTime, nullable=True)
    tags = db.Column(db.String(255))
    comments = db.relationship('Comment', backref='ticket', lazy=True, cascade='all, delete-orphan')
    activities = db.relationship('Activity', backref='ticket', lazy=True, cascade='all, delete-orphan')

    def sla_status(self):
        if not self.due_date:
            return 'none'
        now = datetime.utcnow()
        if self.status in ('resolved', 'closed'):
            if self.resolved_at and self.resolved_at <= self.due_date:
                return 'met'
            return 'breached'
        if now > self.due_date:
            return 'breached'
        remaining = (self.due_date - now).total_seconds() / 3600
        if remaining < 2:
            return 'at_risk'
        return 'on_track'

    def to_dict(self):
        return {
            'id': self.id,
            'ticket_number': self.ticket_number,
            'title': self.title,
            'description': self.description,
            'status': self.status,
            'priority': self.priority,
            'type': self.type,
            'requester': self.requester.name if self.requester else None,
            'assignee': self.assignee.name if self.assignee else None,
            'category': self.category.name if self.category else None,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None,
            'due_date': self.due_date.isoformat() if self.due_date else None,
            'sla_status': self.sla_status(),
            'tags': self.tags,
        }


class Comment(db.Model):
    __tablename__ = 'comments'
    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.Integer, db.ForeignKey('tickets.id'), nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    is_internal = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    author = db.relationship('User', backref='comments')

    def to_dict(self):
        return {
            'id': self.id,
            'content': self.content,
            'author': self.author.name if self.author else None,
            'is_internal': self.is_internal,
            'created_at': self.created_at.isoformat(),
        }


class Activity(db.Model):
    __tablename__ = 'activities'
    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.Integer, db.ForeignKey('tickets.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    action = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship('User', backref='activities')

    def to_dict(self):
        return {
            'id': self.id,
            'action': self.action,
            'user': self.user.name if self.user else 'System',
            'created_at': self.created_at.isoformat(),
        }


def seed_data():
    if User.query.count() > 0:
        return

    # SLA Policies
    slas = [
        SLAPolicy(name='Critical SLA', priority='critical', response_time_hours=1, resolution_time_hours=4),
        SLAPolicy(name='High SLA', priority='high', response_time_hours=4, resolution_time_hours=8),
        SLAPolicy(name='Medium SLA', priority='medium', response_time_hours=8, resolution_time_hours=24),
        SLAPolicy(name='Low SLA', priority='low', response_time_hours=24, resolution_time_hours=72),
    ]
    db.session.add_all(slas)

    # Categories
    cats = [
        Category(name='Hardware', description='Physical device issues'),
        Category(name='Software', description='Application and OS issues'),
        Category(name='Network', description='Connectivity and network issues'),
        Category(name='Security', description='Security incidents and access'),
        Category(name='HR & Facilities', description='HR and facility requests'),
    ]
    db.session.add_all(cats)

    # Users
    users = [
        User(name='Alex Morgan', email='alex@company.com', role='admin', department='IT', avatar_initials='AM'),
        User(name='Jordan Lee', email='jordan@company.com', role='agent', department='IT Support', avatar_initials='JL'),
        User(name='Sam Rivera', email='sam@company.com', role='agent', department='IT Support', avatar_initials='SR'),
        User(name='Chris Taylor', email='chris@company.com', role='user', department='Marketing', avatar_initials='CT'),
        User(name='Dana Kim', email='dana@company.com', role='user', department='Finance', avatar_initials='DK'),
    ]
    db.session.add_all(users)
    db.session.commit()

    # Tickets
    now = datetime.utcnow()
    tickets_data = [
        dict(ticket_number='TKT-0001', title='Laptop not booting after update', description='My laptop stopped booting after applying the latest Windows update. I see a blue screen with error code 0x0000007E.', status='open', priority='critical', type='incident', requester_id=4, assignee_id=2, category_id=1, sla_policy_id=1, due_date=now + timedelta(hours=3), tags='hardware,boot,windows'),
        dict(ticket_number='TKT-0002', title='VPN connection dropping frequently', description='VPN drops every 15-20 minutes. This started 2 days ago. I am working remotely and this is severely affecting my productivity.', status='in_progress', priority='high', type='incident', requester_id=5, assignee_id=3, category_id=3, sla_policy_id=2, due_date=now + timedelta(hours=6), tags='vpn,network,remote'),
        dict(ticket_number='TKT-0003', title='Request for Adobe Creative Suite license', description='I need Adobe Creative Suite for the new marketing campaign project. Please provision a license for my account.', status='pending', priority='medium', type='service_request', requester_id=4, assignee_id=2, category_id=2, sla_policy_id=3, due_date=now + timedelta(hours=20), tags='software,license,adobe'),
        dict(ticket_number='TKT-0004', title='Email phishing attempt detected', description='Received a suspicious email claiming to be from IT asking for credentials. Forwarding details as requested by security team.', status='open', priority='critical', type='incident', requester_id=5, assignee_id=None, category_id=4, sla_policy_id=1, due_date=now + timedelta(hours=2), tags='security,phishing,email'),
        dict(ticket_number='TKT-0005', title='New employee onboarding setup', description='New hire starting Monday. Need laptop provisioning, email setup, and access to Slack, Jira, and Confluence.', status='in_progress', priority='high', type='service_request', requester_id=4, assignee_id=2, category_id=5, sla_policy_id=2, due_date=now + timedelta(hours=5), tags='onboarding,access,new-hire'),
        dict(ticket_number='TKT-0006', title='Printer offline on 3rd floor', description='The shared printer on the 3rd floor has been offline since yesterday morning. Multiple users are affected.', status='resolved', priority='medium', type='incident', requester_id=5, assignee_id=3, category_id=1, sla_policy_id=3, due_date=now - timedelta(hours=2), resolved_at=now - timedelta(hours=3), tags='printer,hardware,3rd-floor'),
        dict(ticket_number='TKT-0007', title='Slow internet on marketing floor', description='Internet speed on the marketing floor has been unusually slow since this morning. Speed tests show 2 Mbps vs usual 100 Mbps.', status='open', priority='high', type='incident', requester_id=4, assignee_id=3, category_id=3, sla_policy_id=2, due_date=now + timedelta(hours=1), tags='network,internet,performance'),
        dict(ticket_number='TKT-0008', title='Reset MFA for locked account', description='I have been locked out of my account after losing my phone. Need MFA reset to regain access.', status='closed', priority='low', type='service_request', requester_id=5, assignee_id=2, category_id=4, sla_policy_id=4, due_date=now - timedelta(hours=48), resolved_at=now - timedelta(hours=50), tags='mfa,access,account'),
    ]
    tickets = []
    for td in tickets_data:
        t = Ticket(**td)
        t.created_at = now - timedelta(days=len(tickets_data) - len(tickets))
        t.updated_at = now - timedelta(hours=len(tickets))
        tickets.append(t)
        db.session.add(t)
    db.session.commit()

    # Comments
    comments = [
        Comment(ticket_id=1, author_id=2, content='I have remote access to your machine. Running diagnostics now. Can you confirm if you have any external USB devices connected?', is_internal=False),
        Comment(ticket_id=1, author_id=4, content='No USB devices connected. The error screen flashes briefly then restarts.', is_internal=False),
        Comment(ticket_id=1, author_id=2, content='Looks like a corrupted system file. Scheduling a remote session for boot repair.', is_internal=True),
        Comment(ticket_id=2, author_id=3, content='Checked the VPN gateway logs. Seeing timeout errors. Pushing a config update now.', is_internal=True),
        Comment(ticket_id=2, author_id=5, content='Is there an ETA? I have a client call in 2 hours.', is_internal=False),
        Comment(ticket_id=5, author_id=2, content='Laptop has been imaged and configured. Email account created. Working on Slack and Jira access now.', is_internal=False),
    ]
    db.session.add_all(comments)

    # Activities
    activities_data = [
        Activity(ticket_id=1, user_id=2, action='Ticket assigned to Jordan Lee', created_at=now - timedelta(hours=2)),
        Activity(ticket_id=1, user_id=2, action='Status changed from Open to In Progress', created_at=now - timedelta(hours=1)),
        Activity(ticket_id=2, user_id=3, action='Ticket assigned to Sam Rivera', created_at=now - timedelta(hours=5)),
        Activity(ticket_id=6, user_id=3, action='Status changed to Resolved', created_at=now - timedelta(hours=3)),
        Activity(ticket_id=8, user_id=2, action='Status changed to Closed', created_at=now - timedelta(hours=49)),
    ]
    db.session.add_all(activities_data)
    db.session.commit()
