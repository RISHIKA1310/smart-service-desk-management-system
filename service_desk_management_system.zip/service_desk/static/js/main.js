// Fetch open ticket count for sidebar badge
async function loadOpenCount() {
  try {
    const res = await fetch('/api/stats');
    const data = await res.json();
    const badge = document.getElementById('open-count');
    if (badge) badge.textContent = data.open || 0;
  } catch (e) {}
}

// Global search redirect
const globalSearch = document.getElementById('global-search');
if (globalSearch) {
  globalSearch.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && globalSearch.value.trim()) {
      window.location = `/tickets/?search=${encodeURIComponent(globalSearch.value.trim())}`;
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  loadOpenCount();

  // Auto-dismiss alerts
  setTimeout(() => {
    document.querySelectorAll('.alert').forEach(a => {
      const bsAlert = bootstrap.Alert.getOrCreateInstance(a);
      bsAlert.close();
    });
  }, 4000);
});
