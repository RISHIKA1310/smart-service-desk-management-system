from flask import Blueprint, jsonify, request
from models import Ticket, User, Category, SLAPolicy, db
from datetime import datetime, timedelta

api_bp = Blueprint('api', __name__)

# --- Tickets ---
@api_bp.route('/tickets', methods=['GET'])
def get_tickets():
    status = request.args.get('status')
    priority = request.args.get('priority')
    query = Ticket.query
    if status:
        query = query.filter(Ticket.status == status)
    if priority:
        query = query.filter(Ticket.priority == priority)
    tickets = query.order_by(Ticket.created_at.desc()).all()
    return jsonify({'tickets': [t.to_dict() for t in tickets], 'count': len(tickets)})

@api_bp.route('/tickets/<int:ticket_id>', methods=['GET'])
def get_ticket(ticket_id):
    ticket = Ticket.query.get_or_404(ticket_id)
    return jsonify(ticket.to_dict())

@api_bp.route('/tickets', methods=['POST'])
def create_ticket():
    data = request.get_json()
    if not data or not data.get('title') or not data.get('description'):
        return jsonify({'error': 'title and description are required'}), 400

    last = Ticket.query.order_by(Ticket.id.desc()).first()
    num = (last.id + 1) if last else 1
    ticket_number = f'TKT-{num:04d}'

    priority = data.get('priority', 'medium')
    hours_map = {'critical': 4, 'high': 8, 'medium': 24, 'low': 72}
    due_date = datetime.utcnow() + timedelta(hours=hours_map.get(priority, 24))

    ticket = Ticket(
        ticket_number=ticket_number,
        title=data['title'],
        description=data['description'],
        priority=priority,
        type=data.get('type', 'incident'),
        status=data.get('status', 'open'),
        requester_id=data.get('requester_id', 1),
        assignee_id=data.get('assignee_id'),
        category_id=data.get('category_id'),
        tags=data.get('tags', ''),
        due_date=due_date,
    )
    db.session.add(ticket)
    db.session.commit()
    return jsonify(ticket.to_dict()), 201

@api_bp.route('/tickets/<int:ticket_id>', methods=['PUT'])
def update_ticket(ticket_id):
    ticket = Ticket.query.get_or_404(ticket_id)
    data = request.get_json()
    if 'status' in data:
        if ticket.status not in ('resolved', 'closed') and data['status'] in ('resolved', 'closed'):
            ticket.resolved_at = datetime.utcnow()
        ticket.status = data['status']
    if 'priority' in data:
        ticket.priority = data['priority']
    if 'assignee_id' in data:
        ticket.assignee_id = data['assignee_id']
    if 'title' in data:
        ticket.title = data['title']
    ticket.updated_at = datetime.utcnow()
    db.session.commit()
    return jsonify(ticket.to_dict())

@api_bp.route('/tickets/<int:ticket_id>', methods=['DELETE'])
def delete_ticket(ticket_id):
    ticket = Ticket.query.get_or_404(ticket_id)
    db.session.delete(ticket)
    db.session.commit()
    return jsonify({'message': f'Ticket {ticket_id} deleted'}), 200

# --- Users ---
@api_bp.route('/users', methods=['GET'])
def get_users():
    users = User.query.all()
    return jsonify({'users': [u.to_dict() for u in users]})

# --- Stats ---
@api_bp.route('/stats', methods=['GET'])
def get_stats():
    from sqlalchemy import func
    status_counts = db.session.query(Ticket.status, func.count(Ticket.id)).group_by(Ticket.status).all()
    priority_counts = db.session.query(Ticket.priority, func.count(Ticket.id)).group_by(Ticket.priority).all()
    all_tickets = Ticket.query.all()
    sla_met = sum(1 for t in all_tickets if t.sla_status() == 'met')
    sla_breached = sum(1 for t in all_tickets if t.sla_status() == 'breached')
    return jsonify({
        'total': Ticket.query.count(),
        'open': Ticket.query.filter(Ticket.status == 'open').count(),
        'in_progress': Ticket.query.filter(Ticket.status == 'in_progress').count(),
        'resolved': Ticket.query.filter(Ticket.status.in_(['resolved', 'closed'])).count(),
        'critical': Ticket.query.filter(Ticket.priority == 'critical', Ticket.status.notin_(['resolved', 'closed'])).count(),
        'by_status': dict(status_counts),
        'by_priority': dict(priority_counts),
        'sla': {'met': sla_met, 'breached': sla_breached},
    })

# --- Categories & SLA ---
@api_bp.route('/categories', methods=['GET'])
def get_categories():
    cats = Category.query.all()
    return jsonify({'categories': [c.to_dict() for c in cats]})

@api_bp.route('/sla-policies', methods=['GET'])
def get_sla_policies():
    slas = SLAPolicy.query.all()
    return jsonify({'sla_policies': [s.to_dict() for s in slas]})
