from flask import Blueprint, render_template
from models import Ticket, User, Activity, db
from sqlalchemy import func
from datetime import datetime, timedelta

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/')
def index():
    total = Ticket.query.count()
    open_tickets = Ticket.query.filter(Ticket.status == 'open').count()
    in_progress = Ticket.query.filter(Ticket.status == 'in_progress').count()
    resolved_today = Ticket.query.filter(
        Ticket.status.in_(['resolved', 'closed']),
        Ticket.resolved_at >= datetime.utcnow().replace(hour=0, minute=0, second=0)
    ).count()
    critical = Ticket.query.filter(Ticket.priority == 'critical', Ticket.status.in_(['open', 'in_progress'])).count()

    recent_tickets = Ticket.query.order_by(Ticket.created_at.desc()).limit(8).all()
    recent_activity = Activity.query.order_by(Activity.created_at.desc()).limit(10).all()
    agents = User.query.filter(User.role.in_(['agent', 'admin'])).all()

    # Ticket counts by status for charts
    status_counts = db.session.query(Ticket.status, func.count(Ticket.id)).group_by(Ticket.status).all()
    priority_counts = db.session.query(Ticket.priority, func.count(Ticket.id)).group_by(Ticket.priority).all()

    # SLA compliance
    all_tickets = Ticket.query.all()
    sla_met = sum(1 for t in all_tickets if t.sla_status() == 'met')
    sla_breached = sum(1 for t in all_tickets if t.sla_status() == 'breached')

    return render_template('dashboard.html',
        total=total,
        open_tickets=open_tickets,
        in_progress=in_progress,
        resolved_today=resolved_today,
        critical=critical,
        recent_tickets=recent_tickets,
        recent_activity=recent_activity,
        agents=agents,
        status_counts=dict(status_counts),
        priority_counts=dict(priority_counts),
        sla_met=sla_met,
        sla_breached=sla_breached,
    )
