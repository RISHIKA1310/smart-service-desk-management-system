from flask import Blueprint, render_template, request, redirect, url_for, flash
from models import Ticket, User, Category, SLAPolicy, Comment, Activity, db
from datetime import datetime, timedelta

tickets_bp = Blueprint('tickets', __name__)

def generate_ticket_number():
    last = Ticket.query.order_by(Ticket.id.desc()).first()
    num = (last.id + 1) if last else 1
    return f'TKT-{num:04d}'

def get_due_date(priority, sla_policies):
    hours_map = {'critical': 4, 'high': 8, 'medium': 24, 'low': 72}
    hours = hours_map.get(priority, 24)
    return datetime.utcnow() + timedelta(hours=hours)

@tickets_bp.route('/')
def list_tickets():
    status_filter = request.args.get('status', '')
    priority_filter = request.args.get('priority', '')
    type_filter = request.args.get('type', '')
    search = request.args.get('search', '')

    query = Ticket.query
    if status_filter:
        query = query.filter(Ticket.status == status_filter)
    if priority_filter:
        query = query.filter(Ticket.priority == priority_filter)
    if type_filter:
        query = query.filter(Ticket.type == type_filter)
    if search:
        query = query.filter(
            (Ticket.title.ilike(f'%{search}%')) |
            (Ticket.ticket_number.ilike(f'%{search}%'))
        )

    tickets = query.order_by(Ticket.created_at.desc()).all()
    return render_template('tickets/list.html', tickets=tickets,
                           status_filter=status_filter,
                           priority_filter=priority_filter,
                           type_filter=type_filter,
                           search=search)

@tickets_bp.route('/new', methods=['GET', 'POST'])
def new_ticket():
    users = User.query.all()
    categories = Category.query.all()
    sla_policies = SLAPolicy.query.all()

    if request.method == 'POST':
        ticket = Ticket(
            ticket_number=generate_ticket_number(),
            title=request.form['title'],
            description=request.form['description'],
            priority=request.form['priority'],
            type=request.form['type'],
            requester_id=int(request.form['requester_id']),
            assignee_id=int(request.form['assignee_id']) if request.form.get('assignee_id') else None,
            category_id=int(request.form['category_id']) if request.form.get('category_id') else None,
            tags=request.form.get('tags', ''),
            status='open',
        )
        ticket.due_date = get_due_date(ticket.priority, sla_policies)
        db.session.add(ticket)
        db.session.flush()

        activity = Activity(ticket_id=ticket.id, user_id=ticket.requester_id, action=f'Ticket {ticket.ticket_number} created')
        db.session.add(activity)
        db.session.commit()

        flash(f'Ticket {ticket.ticket_number} created successfully!', 'success')
        return redirect(url_for('tickets.view_ticket', ticket_id=ticket.id))

    return render_template('tickets/new.html', users=users, categories=categories, sla_policies=sla_policies)

@tickets_bp.route('/<int:ticket_id>')
def view_ticket(ticket_id):
    ticket = Ticket.query.get_or_404(ticket_id)
    users = User.query.all()
    agents = User.query.filter(User.role.in_(['agent', 'admin'])).all()
    return render_template('tickets/view.html', ticket=ticket, users=users, agents=agents)

@tickets_bp.route('/<int:ticket_id>/update', methods=['POST'])
def update_ticket(ticket_id):
    ticket = Ticket.query.get_or_404(ticket_id)
    old_status = ticket.status

    ticket.status = request.form.get('status', ticket.status)
    ticket.priority = request.form.get('priority', ticket.priority)
    ticket.assignee_id = int(request.form['assignee_id']) if request.form.get('assignee_id') else None
    ticket.updated_at = datetime.utcnow()

    if ticket.status in ('resolved', 'closed') and old_status not in ('resolved', 'closed'):
        ticket.resolved_at = datetime.utcnow()

    activity = Activity(ticket_id=ticket.id, action=f'Ticket updated: status={ticket.status}, priority={ticket.priority}')
    db.session.add(activity)
    db.session.commit()

    flash('Ticket updated successfully!', 'success')
    return redirect(url_for('tickets.view_ticket', ticket_id=ticket.id))

@tickets_bp.route('/<int:ticket_id>/comment', methods=['POST'])
def add_comment(ticket_id):
    ticket = Ticket.query.get_or_404(ticket_id)
    content = request.form.get('content', '').strip()
    is_internal = request.form.get('is_internal') == 'on'
    author_id = int(request.form.get('author_id', 1))

    if content:
        comment = Comment(ticket_id=ticket.id, author_id=author_id, content=content, is_internal=is_internal)
        db.session.add(comment)
        activity = Activity(ticket_id=ticket.id, user_id=author_id, action='Comment added')
        db.session.add(activity)
        db.session.commit()
        flash('Comment added.', 'success')

    return redirect(url_for('tickets.view_ticket', ticket_id=ticket.id))
